<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Liquidation extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'route_id',
        'collector_id',
        'liquidation_date',
        'base_amount',
        'cross_amount',
        'credit_amount',
        'collection_amount',
        'renewal_amount',
        'expense_amount',
        'surcharge_amount',
        'total_clients',
        'processed_clients',
        'missing_clients',
        'excess_clients',
        'status',
        'error_details'
    ];

    protected $casts = [
        'liquidation_date' => 'datetime',
        'base_amount' => 'decimal:2',
        'cross_amount' => 'decimal:2',
        'credit_amount' => 'decimal:2',
        'collection_amount' => 'decimal:2',
        'renewal_amount' => 'decimal:2',
        'expense_amount' => 'decimal:2',
        'surcharge_amount' => 'decimal:2'
    ];

    public function ruta()
    {
        return $this->belongsTo(Ruta::class, 'route_id');
    }

    public function collector()
    {
        return $this->belongsTo(User::class, 'collector_id');
    }
}

