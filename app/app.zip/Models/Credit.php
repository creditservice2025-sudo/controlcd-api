<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Credit extends Model
{
    use HasFactory;

    protected $fillable = [
        'active',
        'member_id',
        'route_id',
        'total_value',
        'quota_value',
        'total_quotas',
        'start_date',
        'end_date',
        'first_payment_date',
        'payment_frequency',
        'payment_day',
        'credit_counts'
    ];

    protected $casts = [
        'active' => 'boolean',
        'credit_counts' => 'array',
        'start_date' => 'date',
        'end_date' => 'date',
        'first_payment_date' => 'date',
    ];

    public function member()
    {
        return $this->belongsTo(Member::class);
    }

    public function ruta()
    {
        return $this->belongsTo(Ruta::class, 'route_id');
    }
}