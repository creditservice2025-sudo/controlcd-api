<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ruta extends Model
{
    use HasFactory;

    protected $table = 'rutas';

    protected $fillable = [
        'active',
        'name',
        'sector',
        'balance',
        'credits',
    ];

    protected $casts = [
        'credits' => 'array',
    ];

    public function members()
    {
        return $this->belongsToMany(Member::class, 'member_ruta');
    }

    public function credits()
    {
        return $this->hasMany(Credit::class, 'route_id');
    }
}