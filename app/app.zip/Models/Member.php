<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    use HasFactory;

    protected $fillable = [
        'active',
        'name',
        'identification',
        'role',
        'department',
        'address',
        'city',
        'email',
        'phone',
    ];


    public function rutas()
    {
        return $this->belongsToMany(Ruta::class, 'member_ruta');
    }
    public function credits()
    {
        return $this->hasMany(Credit::class);
    }
}

