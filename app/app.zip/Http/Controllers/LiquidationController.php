<?php

namespace App\Http\Controllers;

use App\Models\Liquidation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class LiquidationController extends Controller
{
    public function index()
    {
        $liquidations = Liquidation::with(['ruta', 'collector']) // Updated route relationship
            ->orderBy('liquidation_date', 'desc')
            ->paginate(10);

        return response()->json($liquidations);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'route_id' => 'required|exists:rutas,id', // Updated route validation rule
            'collector_id' => 'required|exists:users,id',
            'liquidation_date' => 'required|date',
            'base_amount' => 'required|numeric|min:0',
            'cross_amount' => 'required|numeric|min:0',
            'credit_amount' => 'required|numeric|min:0',
            'collection_amount' => 'required|numeric|min:0',
            'renewal_amount' => 'required|numeric|min:0',
            'expense_amount' => 'required|numeric|min:0',
            'surcharge_amount' => 'required|numeric|min:0'
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        try {
            DB::beginTransaction();

            $liquidation = Liquidation::create($request->all());

            // Aquí iría la lógica para procesar la liquidación
            // Por ejemplo, actualizar estados de créditos, calcular totales, etc.

            DB::commit();

            return response()->json([
                'message' => 'Liquidación creada exitosamente',
                'liquidation' => $liquidation
            ], 201);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'message' => 'Error al crear la liquidación',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function show(Liquidation $liquidation)
    {
        return response()->json($liquidation->load(['ruta', 'collector'])); // Updated route relationship
    }

    public function update(Request $request, Liquidation $liquidation)
    {
        $validator = Validator::make($request->all(), [
            'base_amount' => 'numeric|min:0',
            'cross_amount' => 'numeric|min:0',
            'credit_amount' => 'numeric|min:0',
            'collection_amount' => 'numeric|min:0',
            'renewal_amount' => 'numeric|min:0',
            'expense_amount' => 'numeric|min:0',
            'surcharge_amount' => 'numeric|min:0'
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        try {
            DB::beginTransaction();

            $liquidation->update($request->all());

            DB::commit();

            return response()->json([
                'message' => 'Liquidación actualizada exitosamente',
                'liquidation' => $liquidation
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'message' => 'Error al actualizar la liquidación',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function destroy(Liquidation $liquidation)
    {
        try {
            $liquidation->delete();
            return response()->json([
                'message' => 'Liquidación eliminada exitosamente'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Error al eliminar la liquidación',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function massLiquidation(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'route_ids' => 'required|array',
            'route_ids.*' => 'exists:rutas,id' // Updated route validation rule
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        try {
            DB::beginTransaction();

            $results = [];
            foreach ($request->route_ids as $routeId) {
                // Aquí iría la lógica para procesar cada liquidación masiva
                // Por ejemplo, verificar abonos nuevos, crear liquidación, etc.
            }

            DB::commit();

            return response()->json([
                'message' => 'Liquidación masiva completada',
                'results' => $results
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'message' => 'Error en la liquidación masiva',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}

