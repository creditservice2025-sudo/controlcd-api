<?php

namespace App\Http\Controllers;

use App\Models\Ruta;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RutaController extends Controller
{
    public function index()
    {
        return Ruta::with('members')->get();
    }

    public function show($id)
    {
        return Ruta::with('members')->findOrFail($id);
    }

    public function store(Request $request)
    {
        DB::beginTransaction();
        try {
            $ruta = Ruta::create($request->except('members'));
            if ($request->has('members')) {
                $ruta->members()->attach($request->members);
            }
            DB::commit();
            return response()->json($ruta->load('members'), 201);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function update(Request $request, $id)
    {
        DB::beginTransaction();
        try {
            $ruta = Ruta::findOrFail($id);
            $ruta->update($request->except('members'));
            if ($request->has('members')) {
                $ruta->members()->sync($request->members);
            }
            DB::commit();
            return response()->json($ruta->load('members'), 200);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['error' => $e->getMessage()], 500);
        }
    }

    public function destroy($id)
    {
        $ruta = Ruta::findOrFail($id);
        $ruta->delete();
        return response()->json(['message' => 'Ruta deleted successfully'], 200);
    }

    public function bulkDelete(Request $request)
    {
        $ids = $request->input('ids');
        Ruta::whereIn('id', $ids)->delete();
        return response()->json(['message' => 'Rutas deleted successfully'], 200);
    }

    public function assignMembers(Request $request, $id)
    {
        $ruta = Ruta::findOrFail($id);
        $memberIds = $request->input('member_ids');
        
        $ruta->members()->sync($memberIds);
        
        return response()->json(['message' => 'Miembros asignados exitosamente'], 200);
    }
}