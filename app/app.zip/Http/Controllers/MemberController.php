<?php

namespace App\Http\Controllers;

use App\Models\Member;
use Illuminate\Http\Request;

class MemberController extends Controller
{
    // Lista todos los miembros
    public function index()
    {
        return Member::with('rutas')->get();
    }

    // Muestra un miembro específico
    public function show($id)
    {
        return Member::find($id);
    }

    // Crea un nuevo miembro
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'active' => 'required|boolean',
            'name' => 'required|string',
            'identification' => 'required|string',
            'role' => 'required|string',
            'department' => 'required|string',
            'address' => 'required|string',
            'city' => 'required|string',
            'email' => 'required|email',
            'phone' => 'required|string',
            'rutas' => 'array'
        ]);

        $member = Member::create($validatedData);

        if ($request->has('rutas')) {
            $rutaIds = collect($request->rutas)->pluck('value')->toArray();
            $member->rutas()->sync($rutaIds);
        }

        return response()->json($member->load('rutas'), 201);
    }

    public function update(Request $request, $id)
    {
        $member = Member::findOrFail($id);

        $validatedData = $request->validate([
            'active' => 'boolean',
            'name' => 'string',
            'identification' => 'string',
            'role' => 'string',
            'department' => 'string',
            'address' => 'string',
            'city' => 'string',
            'email' => 'email',
            'phone' => 'string',
            'rutas' => 'array'
        ]);

        $member->update($validatedData);

        if ($request->has('rutas')) {
            $rutaIds = collect($request->rutas)->pluck('value')->toArray();
            $member->rutas()->sync($rutaIds);
        }

        return response()->json($member->load('rutas'), 200);
    }
    public function bulkDelete(Request $request)
    {
        $ids = $request->input('ids');
        Member::whereIn('id', $ids)->delete();
        return response()->json(['message' => 'Members deleted successfully'], 200);
    }

    // Elimina un miembro
    public function destroy($id)
    {
        $member = Member::findOrFail($id);
        $member->delete();
        return response()->json(['message' => 'Member deleted successfully'], 200);
    }
}
