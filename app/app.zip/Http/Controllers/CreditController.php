<?php

namespace App\Http\Controllers;

use App\Models\Credit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CreditController extends Controller
{
    public function index()
    {
        return Credit::with(['member', 'ruta'])
            ->orderBy('created_at', 'desc')
            ->get();
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'member_id' => 'required|exists:members,id',
            'route_id' => 'required|exists:rutas,id',
            'total_value' => 'required|numeric|min:0',
            'quota_value' => 'required|numeric|min:0',
            'total_quotas' => 'required|integer|min:1',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
            'first_payment_date' => 'required|date|after_or_equal:start_date',
            'payment_frequency' => 'required|in:daily,weekly,biweekly,monthly',
            'payment_day' => 'nullable|integer|min:1|max:31',
            'credit_counts' => 'nullable|array'
        ]);

        return Credit::create($validated);
    }

    public function show(Credit $credit)
    {
        return $credit->load(['member', 'ruta']);
    }

    public function update(Request $request, Credit $credit)
    {
        $validated = $request->validate([
            'active' => 'boolean',
            'member_id' => 'exists:members,id',
            'route_id' => 'exists:rutas,id',
            'total_value' => 'numeric|min:0',
            'quota_value' => 'numeric|min:0',
            'total_quotas' => 'integer|min:1',
            'start_date' => 'date',
            'end_date' => 'date|after:start_date',
            'first_payment_date' => 'date|after_or_equal:start_date',
            'payment_frequency' => 'in:daily,weekly,biweekly,monthly',
            'payment_day' => 'nullable|integer|min:1|max:31',
            'credit_counts' => 'nullable|array'
        ]);

        $credit->update($validated);
        return $credit;
    }

    public function destroy(Credit $credit)
    {
        $credit->delete();
        return response()->json(['message' => 'Credit deleted successfully'], 200);
    }
    public function bulkDelete(Request $request)
    {
        $ids = $request->input('ids');
        Credit::whereIn('id', $ids)->delete();
        return response()->json(['message' => 'Credits deleted successfully'], 200);
    }

    public function bulkToggle(Request $request)
    {
        $validated = $request->validate([
            'ids' => 'required|array',
            'ids.*' => 'exists:credits,id',
            'active' => 'required|boolean'
        ]);

        DB::table('credits')
            ->whereIn('id', $validated['ids'])
            ->update(['active' => $validated['active']]);

        return response()->json(['message' => 'Credits updated successfully']);
    }

    public function cancelNewCredits()
    {
        $canceledCount = Credit::where('active', true)
            ->whereDoesntHave('payments')
            ->update(['active' => false]);

        return response()->json(['message' => 'New credits without payments canceled', 'count' => $canceledCount]);
    }

    public function deactivateMembersWithoutPayments()
    {
        $deactivatedCount = Member::whereDoesntHave('credits.payments')
            ->update(['active' => false]);

        return response()->json(['message' => 'Members without payments deactivated', 'count' => $deactivatedCount]);
    }

    public function reactivateInactiveMembers()
    {
        $reactivatedCount = Member::where('active', false)
            ->update(['active' => true]);

        return response()->json(['message' => 'Inactive members reactivated', 'count' => $reactivatedCount]);
    }

    public function deleteInactiveMembers()
    {
        $deletedCount = Member::where('active', false)->delete();

        return response()->json(['message' => 'Inactive members deleted', 'count' => $deletedCount]);
    }
}